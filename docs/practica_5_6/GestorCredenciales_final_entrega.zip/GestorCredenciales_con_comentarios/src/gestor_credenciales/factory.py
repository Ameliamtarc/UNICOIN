"""
factory.py — Secure Strategy Factory para cifradores.
======================================================
Práctica 6 — Implementado por: Gael Espín

Patrón aplicado:
  - Secure Strategy Factory: la fábrica selecciona y devuelve el
    cifrador apropiado según las credenciales/entorno del cliente.

Principios de seguridad aplicados:
  - A prueba de fallos por defecto : si las credenciales no son válidas
                                     o el tipo pedido no existe, la fábrica
                                     lanza PermissionError / ValueError
                                     en lugar de devolver un objeto por defecto.
  - Mínimo privilegio              : solo se concede acceso al cifrador que
                                     corresponde al rol/entorno del cliente;
                                     un cliente sin privilegios no puede obtener
                                     un cifrador más potente.
  - Mediación completa             : la selección del cifrador siempre pasa
                                     por obtener_cifrador(); no hay acceso directo.
"""

from src.gestor_credenciales.cifrador import CifradorBase, CifradorFernet


# ── Registro de cifradores disponibles ───────────────────────────

_CIFRADORES = {
    "fernet": CifradorFernet,
    # Aquí se añadirán nuevos cifradores sin modificar la fábrica (OCP):
    # "aes-gcm": CifradorAESGCM,
}

# Mapa de roles a cifradores permitidos (mínimo privilegio)
_ROL_A_CIFRADOR = {
    "admin":    "fernet",
    "usuario":  "fernet",
    # En un sistema real, roles distintos podrían tener algoritmos distintos
}


class CifradorFactory:
    """
    Fábrica de Estrategias Segura.

    Uso básico (tipo explícito):
        cifrador = CifradorFactory.obtener_cifrador("fernet")

    Uso por credenciales (rol):
        cifrador = CifradorFactory.obtener_cifrador_para_rol("admin", clave_valida)
    """

    @staticmethod
    def obtener_cifrador(tipo: str = "fernet") -> CifradorBase:
        """
        Devuelve el cifrador correspondiente a *tipo*.

        Parámetros
        ----------
        tipo : nombre del algoritmo de cifrado (ej. "fernet").

        Excepciones
        -----------
        ValueError si *tipo* no está registrado (a prueba de fallos).
        """
        clase = _CIFRADORES.get(tipo)
        if clase is None:
            raise ValueError(
                f"Cifrador desconocido: '{tipo}'. "
                f"Disponibles: {list(_CIFRADORES.keys())}"
            )
        return clase()

    @staticmethod
    def obtener_cifrador_para_rol(rol: str, clave_maestra: str | None) -> CifradorBase:
        """
        Selecciona el cifrador apropiado para *rol*, verificando que
        *clave_maestra* sea una string no vacía (autenticidad mínima).

        Mínimo privilegio: solo los roles reconocidos reciben un cifrador;
        cualquier rol desconocido recibe PermissionError.

        Parámetros
        ----------
        rol           : identificador del rol del cliente.
        clave_maestra : clave presentada por el cliente (debe ser no vacía).

        Excepciones
        -----------
        PermissionError si el rol no está autorizado o la clave está vacía.
        ValueError      si el tipo de cifrador asociado al rol no existe.
        """
        if not isinstance(clave_maestra, str) or len(clave_maestra) == 0:
            raise PermissionError("Se requiere una clave maestra válida para obtener un cifrador.")

        tipo = _ROL_A_CIFRADOR.get(rol)
        if tipo is None:
            raise PermissionError(
                f"Rol '{rol}' no autorizado para obtener un cifrador."
            )

        return CifradorFactory.obtener_cifrador(tipo)
