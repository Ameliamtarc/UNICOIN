"""
gestor_credenciales.py
======================
Práctica 5 + 6 — Gestor de Credenciales Seguro.

Principios SOLID aplicados:
  - SRP : GestorCredenciales solo gestiona credenciales; el cifrado
          (cifrador.py), el proxy (proxy.py) y la fábrica (factory.py)
          son módulos con responsabilidades propias.
  - OCP : Nuevos cifradores o backends de almacenamiento se añaden
          sin modificar esta clase.
  - DIP : GestorCredenciales depende de CifradorBase y
          EstrategiaAlmacenamiento (abstracciones), no de
          implementaciones concretas.

Principios de seguridad aplicados:
  - Economía de mecanismos   : diseño simple y auditable.
  - A prueba de fallos        : toda operación falla cerrado por defecto.
  - Mediación completa        : la clave maestra se verifica en cada acceso
                                (delegado al ProxyGestorCredenciales).
  - Mínimo privilegio         : solo se expone la interfaz mínima necesaria.
  - Registro de compromiso    : todas las acciones quedan en el log.

Patrones aplicados (Práctica 6):
  - Strategy                  : CifradorBase / EstrategiaAlmacenamiento
  - Secure Strategy Factory   : CifradorFactory  (factory.py)
  - Secure Proxy for API      : ProxyGestorCredenciales  (proxy.py)
"""

import icontract
import time
from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from src.gestor_credenciales.utils import (
    validar_password, validar_nombre_servicio, validar_usuario,
)
from src.gestor_credenciales.log_seguro import LogSeguro
from src.gestor_credenciales.cifrador import CifradorBase
from src.gestor_credenciales.factory import CifradorFactory


# ══════════════════════════════════════════════════════════════════
# ABSTRACCIÓN DE ALMACENAMIENTO  (DIP / OCP)
# ══════════════════════════════════════════════════════════════════

class EstrategiaAlmacenamiento(ABC):
    """Interfaz para backends de almacenamiento (Strategy)."""

    @abstractmethod
    def guardar(self, servicio: str, usuario: str, blob: str) -> None: ...

    @abstractmethod
    def recuperar(self, servicio: str, usuario: str) -> Optional[str]: ...

    @abstractmethod
    def eliminar(self, servicio: str, usuario: str) -> bool: ...

    @abstractmethod
    def listar_servicios(self) -> List[str]: ...

    @abstractmethod
    def exportar_todo(self) -> Dict[str, Dict[str, str]]: ...


# ══════════════════════════════════════════════════════════════════
# IMPLEMENTACIÓN DE ALMACENAMIENTO EN MEMORIA
# ══════════════════════════════════════════════════════════════════

class AlmacenamientoMemoria(EstrategiaAlmacenamiento):
    """Backend en memoria (útil para tests y desarrollo)."""

    def __init__(self):
        # { servicio: { usuario: blob_cifrado } }
        self._datos: Dict[str, Dict[str, str]] = {}

    def guardar(self, servicio: str, usuario: str, blob: str) -> None:
        self._datos.setdefault(servicio, {})[usuario] = blob

    def recuperar(self, servicio: str, usuario: str) -> Optional[str]:
        return self._datos.get(servicio, {}).get(usuario)

    def eliminar(self, servicio: str, usuario: str) -> bool:
        if servicio in self._datos and usuario in self._datos[servicio]:
            del self._datos[servicio][usuario]
            if not self._datos[servicio]:
                del self._datos[servicio]
            return True
        return False

    def listar_servicios(self) -> List[str]:
        return list(self._datos.keys())

    def exportar_todo(self) -> Dict[str, Dict[str, str]]:
        """Retorna copia del almacén completo (blobs cifrados, nunca en claro)."""
        return {s: dict(u) for s, u in self._datos.items()}


# ══════════════════════════════════════════════════════════════════
# GESTOR DE CREDENCIALES  (núcleo)
# ══════════════════════════════════════════════════════════════════

# Tiempo máximo de inactividad de sesión en segundos
_TIMEOUT_SESION_SEGUNDOS = 300  # 5 minutos


class GestorCredenciales:
    """
    Componente principal para almacenar y recuperar credenciales de forma segura.
    Depende de abstracciones inyectadas en el constructor (DIP).
    """

    def __init__(
        self,
        clave_maestra: str,
        cifrado: Optional[CifradorBase] = None,
        almacenamiento: Optional[EstrategiaAlmacenamiento] = None,
        log: Optional[LogSeguro] = None,
        timeout_segundos: int = _TIMEOUT_SESION_SEGUNDOS,
    ):
        if not isinstance(clave_maestra, str) or len(clave_maestra) < 8:
            raise ValueError("La clave maestra debe tener al menos 8 caracteres.")

        self._clave              = clave_maestra
        self._cifrado            = cifrado or CifradorFactory.obtener_cifrador("fernet")
        self._store              = almacenamiento or AlmacenamientoMemoria()
        self._log                = log or LogSeguro()
        self._timeout            = timeout_segundos
        self._ultimo_acceso: float = time.time()   # timestamp del último uso

    # ── Control de sesión / timeout ────────────────────────────────

    def _verificar_timeout(self) -> None:
        """
        RS-4 (Autenticidad — timeout de sesión):
        Si ha pasado más tiempo que _timeout desde el último acceso,
        la sesión expira y se lanza PermissionError.
        """
        ahora = time.time()
        if ahora - self._ultimo_acceso > self._timeout:
            self._log.registrar("warning", "Sesión expirada por inactividad.")
            raise PermissionError(
                f"Sesión expirada: inactividad superior a {self._timeout} segundos."
            )
        self._ultimo_acceso = ahora

    # ── Función pública auxiliar ───────────────────────────────────

    @icontract.ensure(lambda result: isinstance(result, str) and len(result) > 0,
                      "Saludar debe devolver un mensaje no vacío.")
    def saludar(self) -> str:
        """
        Retorna un mensaje de bienvenida con información básica del sistema.
        No expone información sensible (mínimo privilegio).
        """
        self._verificar_timeout()
        msg = "GestorCredenciales v1.0 — Sistema de gestión segura de credenciales."
        self._log.registrar("info", "Función saludar() invocada.")
        return msg

    # ── Añadir credencial ──────────────────────────────────────────

    @icontract.require(lambda servicio: validar_nombre_servicio(servicio),
                       "Nombre de servicio inválido (posible inyección).")
    @icontract.require(lambda usuario: validar_usuario(usuario),
                       "Nombre de usuario inválido.")
    @icontract.require(lambda password: validar_password(password),
                       "La contraseña no cumple la política de seguridad.")
    @icontract.ensure(lambda result: result is None,
                      "Añadir credencial no debe devolver información sensible.")
    def anyadir(self, servicio: str, usuario: str, password: str) -> None:
        """
        Almacena las credenciales cifradas.
        Precondiciones: servicio válido, usuario válido, password robusto.
        """
        self._verificar_timeout()
        blob = self._cifrado.cifrar(password, self._clave)
        self._store.guardar(servicio, usuario, blob)
        # Prevención de logging sensitivo: NUNCA se loguea la contraseña
        self._log.registrar(
            "info",
            f"Credencial añadida: servicio='{servicio}' usuario='{usuario}'"
        )

    def añadir(self, servicio: str, usuario: str, password: str) -> None:
        """Alias compatible para clientes y tests que usan el nombre con ñ."""
        return self.anyadir(servicio, usuario, password)

    # ── Recuperar credencial ───────────────────────────────────────

    @icontract.require(lambda servicio: validar_nombre_servicio(servicio),
                       "Nombre de servicio inválido.")
    @icontract.require(lambda usuario: validar_usuario(usuario),
                       "Nombre de usuario inválido.")
    @icontract.ensure(lambda result: isinstance(result, str) and len(result) > 0,
                      "Recuperar debe devolver una contraseña no vacía.")
    def recuperar(self, servicio: str, usuario: str) -> str:
        """
        Recupera y descifra la contraseña.
        Lanza KeyError si no existe; ValueError si la integridad falla.
        """
        self._verificar_timeout()
        blob = self._store.recuperar(servicio, usuario)
        if blob is None:
            self._log.registrar(
                "warning",
                f"Credencial no encontrada: servicio='{servicio}' usuario='{usuario}'"
            )
            raise KeyError(f"No existe credencial para '{servicio}'/'{usuario}'.")

        password = self._cifrado.descifrar(blob, self._clave)
        self._log.registrar(
            "info",
            f"Credencial recuperada: servicio='{servicio}' usuario='{usuario}'"
        )
        return password

    # ── Eliminar credencial ────────────────────────────────────────

    @icontract.require(lambda servicio: validar_nombre_servicio(servicio),
                       "Nombre de servicio inválido.")
    @icontract.require(lambda usuario: validar_usuario(usuario),
                       "Nombre de usuario inválido.")
    @icontract.ensure(lambda result: isinstance(result, bool),
                      "Eliminar debe devolver un booleano.")
    def eliminar(self, servicio: str, usuario: str) -> bool:
        """Elimina la credencial indicada. Retorna True si existía."""
        self._verificar_timeout()
        eliminado = self._store.eliminar(servicio, usuario)
        nivel = "info" if eliminado else "warning"
        self._log.registrar(
            nivel,
            f"Eliminar credencial: servicio='{servicio}' usuario='{usuario}' éxito={eliminado}"
        )
        return eliminado

    # ── Listar servicios ───────────────────────────────────────────

    @icontract.ensure(
        lambda result: isinstance(result, list)
        and all(validar_nombre_servicio(servicio) for servicio in result),
        "El listado solo debe contener nombres de servicio válidos.",
    )
    def listar_servicios(self) -> List[str]:
        """Retorna la lista de servicios con credenciales almacenadas."""
        self._verificar_timeout()
        servicios = self._store.listar_servicios()
        self._log.registrar(
            "info",
            f"Listado de servicios solicitado: {len(servicios)} servicios"
        )
        return servicios

    # ── Exportar credenciales cifradas ─────────────────────────────

    @icontract.ensure(lambda result: isinstance(result, dict),
                      "La exportación debe devolver un diccionario.")
    def exportar_credenciales_cifradas(self) -> Dict[str, Dict[str, str]]:
        """
        Exporta todas las credenciales en formato cifrado (nunca en claro).
        Los valores son blobs cifrados; la estructura es
        { servicio: { usuario: blob_cifrado } }.

        RS-1 (Confidencialidad): los blobs nunca contienen contraseñas en claro.
        """
        self._verificar_timeout()
        exportado = self._store.exportar_todo()
        self._log.registrar(
            "info",
            f"Exportación de credenciales cifradas: {len(exportado)} servicios."
        )
        return exportado
