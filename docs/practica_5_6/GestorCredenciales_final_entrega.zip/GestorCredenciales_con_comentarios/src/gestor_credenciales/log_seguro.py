"""
log_seguro.py — Log de auditoría con hash encadenado.
Principio aplicado: Registro de compromiso (audit trail).
Prevención de logging sensitivo: solo se loguean metadatos, nunca contraseñas.
"""

import hashlib
import logging
import os
from datetime import datetime, timezone


class LogSeguro:
    def __init__(self, log_file: str = "gestor_credenciales.log"):
        self._log_file = log_file
        self._ultimo_hash = ""
        self._logger = self._configurar_logger(log_file)
        self._inicializar()

    def _configurar_logger(self, log_file: str) -> logging.Logger:
        nombre = f"gestor_cred_{os.getpid()}_{id(self)}"
        logger = logging.getLogger(nombre)
        logger.setLevel(logging.DEBUG)
        logger.propagate = False
        handler = logging.FileHandler(log_file, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
        return logger

    def _calcular_hash(self, contenido: str) -> str:
        return hashlib.sha256(contenido.encode("utf-8")).hexdigest()

    def _inicializar(self):
        ahora_local = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ahora_utc   = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        mensaje = f"Inicialización del log en el tiempo {ahora_utc}"
        h = self._calcular_hash(mensaje)
        self._ultimo_hash = h
        self._logger.info(f"{ahora_local}: INFO | '{h}': {mensaje} |")

    def registrar(self, nivel: str, mensaje: str) -> None:
        ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        contenido = mensaje + self._ultimo_hash
        h = self._calcular_hash(contenido)
        self._ultimo_hash = h
        nivel_map = {"info": logging.INFO, "warning": logging.WARNING,
                     "error": logging.ERROR, "debug": logging.DEBUG}
        linea = f"{ahora}: {nivel.upper()} | '{h}': {mensaje} |"
        self._logger.log(nivel_map.get(nivel.lower(), logging.INFO), linea)
