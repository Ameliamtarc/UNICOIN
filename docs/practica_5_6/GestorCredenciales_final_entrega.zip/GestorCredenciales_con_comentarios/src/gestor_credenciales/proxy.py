"""
proxy.py — Secure Proxy for API para el GestorCredenciales.
============================================================
Práctica 6 — Implementado por: Enrique Pérez

Patrón aplicado:
  - Secure Proxy for API: cada operación pasa por el proxy, que
    autentica la clave maestra antes de redirigir al gestor real.

Principios de seguridad aplicados:
  - Mediación completa  : TODA operación sobre el gestor real pasa
                          obligatoriamente por _autenticar().
  - Registro de compromiso : cada intento (exitoso o fallido) queda
                             registrado en el log con su resultado.
  - A prueba de fallos  : acceso denegado por defecto ante clave errónea.
"""

from typing import List, Optional

from src.gestor_credenciales.log_seguro import LogSeguro


class ProxyGestorCredenciales:
    """
    Proxy seguro que autentica la clave maestra antes de redirigir
    cada petición al GestorCredenciales real.

    Implementa el patrón Secure Proxy for API:
      1. El cliente llama a cualquier método del proxy pasando la clave.
      2. El proxy verifica la clave (mediación completa).
      3. Si es correcta, redirige al gestor real; si no, lanza PermissionError
         y lo registra en el log (registro de compromiso).
    """

    def __init__(self, gestor, clave_maestra: str, log: Optional[LogSeguro] = None):
        """
        Parameters
        ----------
        gestor        : GestorCredenciales — el objeto real que hace el trabajo.
        clave_maestra : str               — clave que los clientes deben presentar.
        log           : LogSeguro | None  — log de auditoría (se crea uno si no se da).
        """
        self._gestor = gestor
        self._clave  = clave_maestra
        self._log    = log or LogSeguro()

    # ── Mediación completa ────────────────────────────────────────

    def _autenticar(self, clave: str, operacion: str) -> None:
        """
        Verifica que *clave* coincide con la clave maestra.
        Registra el intento en el log independientemente del resultado.
        Lanza PermissionError si la clave es incorrecta.
        """
        if clave == self._clave:
            self._log.registrar(
                "info",
                f"Acceso autorizado al proxy. Operación='{operacion}'"
            )
        else:
            self._log.registrar(
                "warning",
                f"Intento de acceso con clave maestra incorrecta. Operación='{operacion}'"
            )
            raise PermissionError("Clave maestra incorrecta.")

    # ── Operaciones delegadas ─────────────────────────────────────

    def anyadir(self, clave: str, servicio: str, usuario: str, password: str) -> None:
        """Autentica y delega añadir credencial."""
        self._autenticar(clave, "añadir")
        self._gestor.anyadir(servicio, usuario, password)

    def añadir(self, clave: str, servicio: str, usuario: str, password: str) -> None:
        """Alias compatible para clientes y tests que usan el nombre con ñ."""
        return self.anyadir(clave, servicio, usuario, password)

    def recuperar(self, clave: str, servicio: str, usuario: str) -> str:
        """Autentica y delega recuperar credencial."""
        self._autenticar(clave, "recuperar")
        return self._gestor.recuperar(servicio, usuario)

    def eliminar(self, clave: str, servicio: str, usuario: str) -> bool:
        """Autentica y delega eliminar credencial."""
        self._autenticar(clave, "eliminar")
        return self._gestor.eliminar(servicio, usuario)

    def listar_servicios(self, clave: str) -> List[str]:
        """Autentica y delega listar servicios."""
        self._autenticar(clave, "listar_servicios")
        return self._gestor.listar_servicios()
