"""
utils.py — Utilidades de seguridad para el GestorCredenciales.
Principios aplicados:
  - SRP: cada función tiene una única responsabilidad.
  - Economía de mecanismos: implementaciones simples y auditables.
  - A prueba de fallos por defecto: cualquier validación falla cerrado.
"""

import re
import os
import base64
import binascii
import hashlib

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


# ══════════════════════════════════════════════════════════════════
# CIFRADO AES-GCM  (confidencialidad + integridad)
# ══════════════════════════════════════════════════════════════════

def derivar_clave(clave_maestra: str) -> bytes:
    """Deriva una clave AES-256 a partir de la clave maestra usando SHA-256."""
    return hashlib.sha256(clave_maestra.encode("utf-8")).digest()


def cifrar(texto: str, clave_maestra: str) -> str:
    """
    Cifra texto con AES-256-GCM.
    Retorna base64(nonce + ciphertext) como string.
    """
    clave = derivar_clave(clave_maestra)
    aesgcm = AESGCM(clave)
    nonce = os.urandom(12)
    ct = aesgcm.encrypt(nonce, texto.encode("utf-8"), None)
    return base64.b64encode(nonce + ct).decode("utf-8")


def descifrar(blob: str, clave_maestra: str) -> str:
    """
    Descifra un blob producido por `cifrar`.
    Lanza ValueError si el blob ha sido manipulado (integridad AES-GCM).
    """
    try:
        clave = derivar_clave(clave_maestra)
        aesgcm = AESGCM(clave)
        datos = base64.b64decode(blob.encode("utf-8"), validate=True)
        nonce, ct = datos[:12], datos[12:]
        return aesgcm.decrypt(nonce, ct, None).decode("utf-8")
    except (binascii.Error, InvalidTag, UnicodeDecodeError, ValueError) as exc:
        raise ValueError(
            "Integridad comprometida: el blob cifrado ha sido manipulado."
        ) from exc


# ══════════════════════════════════════════════════════════════════
# POLÍTICA DE CONTRASEÑAS  (robustez)
# ══════════════════════════════════════════════════════════════════

PATRON_PASSWORD = re.compile(
    r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]).{12,}$"
)


def validar_password(password: str) -> bool:
    """
    Verifica que la contraseña cumpla la política:
      - Mínimo 12 caracteres
      - Al menos una mayúscula, una minúscula, un dígito y un símbolo
    """
    if not isinstance(password, str):
        return False
    return bool(PATRON_PASSWORD.match(password))


# ══════════════════════════════════════════════════════════════════
# VALIDACIÓN DE ENTRADAS  (protección contra inyección)
# ══════════════════════════════════════════════════════════════════

PATRON_SERVICIO = re.compile(r"^[a-zA-Z0-9_\-\.]{1,64}$")


def validar_nombre_servicio(nombre: str) -> bool:
    """
    Solo permite nombres de servicio alfanuméricos con guion, punto y guion bajo.
    Evita inyección de caracteres especiales.
    """
    if not isinstance(nombre, str):
        return False
    return bool(PATRON_SERVICIO.match(nombre))


def validar_usuario(usuario: str) -> bool:
    """Valida que el nombre de usuario sea un string no vacío y razonable."""
    return isinstance(usuario, str) and 1 <= len(usuario) <= 128
