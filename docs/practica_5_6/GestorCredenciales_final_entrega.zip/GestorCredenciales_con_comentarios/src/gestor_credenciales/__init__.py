"""
Paquete gestor_credenciales.
Exporta las clases e interfaces principales para uso externo.
"""
from src.gestor_credenciales.cifrador import CifradorBase, CifradorFernet
from src.gestor_credenciales.factory import CifradorFactory
from src.gestor_credenciales.proxy import ProxyGestorCredenciales
from src.gestor_credenciales.gestor_credenciales import (
    GestorCredenciales,
    AlmacenamientoMemoria,
    EstrategiaAlmacenamiento,
)
from src.gestor_credenciales.log_seguro import LogSeguro
from src.gestor_credenciales.utils import (
    cifrar, descifrar, validar_password,
    validar_nombre_servicio, validar_usuario,
)
