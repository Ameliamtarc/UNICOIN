"""
cifrador.py — Estrategias de cifrado para el GestorCredenciales.
================================================================
Práctica 6 — Implementado por: Amelia Martínez

Principios aplicados:
  - SRP  : este módulo solo cifra/descifra; no gestiona credenciales.
  - OCP  : se pueden añadir nuevos cifradores (CifradorRSA, etc.) sin
           modificar GestorCredenciales ni CifradorBase.
  - DIP  : GestorCredenciales depende de CifradorBase (abstracción),
           nunca de CifradorFernet directamente.

Principios de seguridad:
  - Economía de mecanismos : implementación mínima y auditable.
  - A prueba de fallos      : cualquier operación fallida lanza excepción
                              en lugar de retornar un valor silencioso.
"""

from abc import ABC, abstractmethod
import base64
import binascii
import os

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC



# ABSTRACCIÓN  (DIP / OCP)


class CifradorBase(ABC):
    """
    Interfaz abstracta para estrategias de cifrado (patrón Strategy).
    GestorCredenciales depende únicamente de esta abstracción.
    """

    @abstractmethod
    def cifrar(self, texto: str, clave: str) -> str:
        """Cifra *texto* usando *clave* y retorna el blob cifrado como str."""
        ...

    @abstractmethod
    def descifrar(self, blob: str, clave: str) -> str:
        """
        Descifra *blob* usando *clave*.
        Lanza ValueError si la integridad o la clave no son correctas.
        """
        ...



_FERNET_VERSION = "v2"
_FERNET_SALT_BYTES = 16
_FERNET_ITERATIONS = 100_000


# Salt antiguo. Solo se conserva para poder descifrar datos ya guardados
# antes de introducir salt aleatorio por credencial.
_FERNET_SALT_LEGACY = b"GestorCredSalt!!"   # 16 bytes


def _derivar_clave_fernet(clave_maestra: str, salt: bytes) -> bytes:
    """
    Deriva una clave Fernet de 32 bytes a partir de la clave maestra
    usando PBKDF2-HMAC-SHA256 y un salt único por credencial.
    """
    if not isinstance(clave_maestra, str) or not clave_maestra:
        raise ValueError("La clave maestra debe ser una cadena no vacía.")

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=_FERNET_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(clave_maestra.encode("utf-8")))


def _codificar_salt(salt: bytes) -> str:
    """Codifica el salt para poder guardarlo junto al token Fernet."""
    return base64.urlsafe_b64encode(salt).decode("ascii")


def _decodificar_salt(salt_codificado: str) -> bytes:
    """Decodifica y valida el salt almacenado en un blob v2."""
    try:
        salt = base64.urlsafe_b64decode(salt_codificado.encode("ascii"))
    except (binascii.Error, UnicodeEncodeError) as exc:
        raise ValueError("Formato de blob cifrado inválido.") from exc

    if len(salt) != _FERNET_SALT_BYTES:
        raise ValueError("Formato de blob cifrado inválido.")
    return salt


class CifradorFernet(CifradorBase):
    """
    Cifrado simétrico con Fernet (AES-128-CBC + HMAC-SHA256).
    Proporciona confidencialidad e integridad (autenticado).

    Al ser intercambiable por cualquier otra subclase de CifradorBase,
    cumple OCP: añadir CifradorAESGCM no requiere tocar el gestor.
    """

    def cifrar(self, texto: str, clave: str) -> str:
        """Cifra texto con Fernet. Retorna token como str."""
        salt = os.urandom(_FERNET_SALT_BYTES)
        f = Fernet(_derivar_clave_fernet(clave, salt))
        token = f.encrypt(texto.encode("utf-8"))
        return f"{_FERNET_VERSION}:{_codificar_salt(salt)}:{token.decode('utf-8')}"

    def descifrar(self, blob: str, clave: str) -> str:
        """
        Descifra un token Fernet.
        Lanza ValueError si el token fue manipulado o la clave es incorrecta.
        """
        if not isinstance(blob, str) or not blob:
            raise ValueError("Formato de blob cifrado inválido.")

        if blob.startswith(f"{_FERNET_VERSION}:"):
            partes = blob.split(":", 2)
            if len(partes) != 3:
                raise ValueError("Formato de blob cifrado inválido.")
            _, salt_codificado, token = partes
            salt = _decodificar_salt(salt_codificado)
        else:
            # Compatibilidad con blobs antiguos generados con salt fijo.
            salt = _FERNET_SALT_LEGACY
            token = blob

        f = Fernet(_derivar_clave_fernet(clave, salt))
        try:
            return f.decrypt(token.encode("utf-8")).decode("utf-8")
        except InvalidToken as exc:
            raise ValueError(
                "Integridad comprometida: token inválido o clave incorrecta."
            ) from exc
