# Gestor de Credenciales Seguro

Proyecto de las practicas 5 y 6 de Ingenieria del Software Seguro.

El componente permite almacenar, recuperar, eliminar y listar credenciales asociadas a servicios. Las contrasenas se almacenan cifradas y las operaciones principales tienen validaciones por contrato.

## Requisitos Cubiertos

- RF-1: anadir credenciales por servicio y usuario.
- RF-2: recuperar la contrasena de un servicio y usuario.
- RF-3: eliminar credenciales existentes.
- RF-4: listar servicios almacenados.
- RS-1: confidencialidad mediante cifrado autenticado.
- RS-2: integridad mediante Fernet/HMAC.
- RS-3: politica robusta de contrasenas.
- RS-4: autenticidad mediante clave maestra y proxy seguro.
- RS-5: auditoria con log seguro.
- RS-6: prevencion de logging sensitivo.
- RS-7: validacion de entradas para prevenir inyeccion.

## Cifrado

Las contrasenas se cifran con `CifradorFernet`, que proporciona cifrado autenticado: oculta el contenido y detecta manipulacion del token o uso de una clave incorrecta.

La clave Fernet se deriva desde la clave maestra con PBKDF2-HMAC-SHA256 y un salt aleatorio por credencial. Los nuevos blobs cifrados usan el formato `v2:<salt_base64>:<token_fernet>`. El descifrado mantiene compatibilidad con blobs antiguos sin prefijo `v2:`.

## Estructura

```text
GestorCredenciales/
├── src/
│   └── gestor_credenciales/
│       ├── cifrador.py
│       ├── factory.py
│       ├── gestor_credenciales.py
│       ├── log_seguro.py
│       ├── proxy.py
│       └── utils.py
├── tests/
│   └── gestor_credenciales/
├── docs/
├── pyproject.toml
├── requirements.txt
└── README.md
```

## Instalacion

Desde la carpeta del proyecto:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
```

Alternativa sin instalacion editable:

```bash
python -m pip install -r requirements.txt
```

## Ejecucion de Tests

```bash
python -m unittest discover -s tests -v
```

Resultado verificado en el entorno de desarrollo:

```text
Ran 56 tests
OK
```

## Patrones y Principios Aplicados

- Strategy: `CifradorBase`, `CifradorFernet` y `EstrategiaAlmacenamiento`.
- Secure Strategy Factory: `CifradorFactory`.
- Secure Proxy for API: `ProxyGestorCredenciales`.
- SRP: separacion entre gestion, cifrado, almacenamiento, proxy y log.
- OCP: el gestor acepta cifradores y almacenamientos inyectados.
- DIP: el gestor depende de abstracciones.
- A prueba de fallos por defecto: errores y accesos no autorizados lanzan excepciones.
- Registro de compromiso: las acciones quedan en log sin contrasenas.

