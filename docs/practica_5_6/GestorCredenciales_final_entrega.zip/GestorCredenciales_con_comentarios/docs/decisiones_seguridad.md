# Decisiones de Diseno de Seguridad

## Cifrado e Integridad

Las contrasenas se cifran con `CifradorFernet`, que proporciona cifrado autenticado. Si un token cifrado se manipula o se intenta descifrar con una clave incorrecta, se lanza `ValueError`.

La clave usada por Fernet se deriva de la clave maestra mediante PBKDF2-HMAC-SHA256 con 100000 iteraciones.

Cada nueva credencial usa un salt aleatorio de 16 bytes, generado con `os.urandom`, y almacenado junto al token cifrado en formato `v2:<salt_base64>:<token_fernet>`. El salt no es secreto: se guarda para poder volver a derivar la misma clave durante el descifrado.

Por compatibilidad, `CifradorFernet` todavia puede descifrar blobs antiguos sin prefijo `v2:` que fueron generados con el salt fijo anterior. Los nuevos cifrados ya no usan ese salt fijo.

## Politica de Contrasenas

Las contrasenas deben cumplir:

- Longitud minima de 12 caracteres.
- Al menos una minuscula.
- Al menos una mayuscula.
- Al menos un digito.
- Al menos un simbolo.

La validacion se aplica con contratos `icontract.require` antes de almacenar credenciales.

## Autenticidad

La clave maestra se valida en la creacion del gestor y se utiliza para derivar la clave de cifrado. Para acceso externo se proporciona `ProxyGestorCredenciales`, que exige presentar la clave maestra en cada operacion.

El proxy aplica mediacion completa sobre su interfaz publica: anadir, recuperar, eliminar y listar.

## Auditoria y Logging Sensitivo

`LogSeguro` registra acciones relevantes con marca temporal y hash encadenado. Los mensajes de log contienen metadatos de operacion, servicio y usuario, pero no contrasenas ni claves maestras.

## Proteccion Contra Inyeccion

Los nombres de servicio se restringen al patron `^[a-zA-Z0-9_\-.]{1,64}$`. Esto evita caracteres habituales en payloads de inyeccion, rutas, saltos de linea y etiquetas HTML.

## Fallo Seguro

Las operaciones fallidas lanzan excepciones explicitas:

- `PermissionError` para acceso no autorizado o sesion expirada.
- `ValueError` para integridad comprometida o configuracion invalida.
- `KeyError` para credenciales inexistentes.

## Patrones de Diseno Seguro

- Strategy: permite sustituir algoritmos de cifrado o almacenamiento sin modificar el gestor.
- Secure Strategy Factory: centraliza la seleccion de cifrador y falla cerrado ante tipos o roles desconocidos.
- Secure Proxy for API: autentica cada peticion antes de delegar en el gestor real.
