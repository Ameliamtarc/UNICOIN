# Informe de Trabajo

## Proyecto

Gestor de Credenciales Seguro, practicas 5 y 6.

## Reparto de Trabajo

| Miembro | Trabajo realizado |
| --- | --- |
| Lara Moriel | Tests funcionales de anadir y eliminar credenciales. Tests del cifrador y patron Strategy. |
| Amelia Martinez | Implementacion del cifrado y pruebas de clave maestra erronea y timeout de sesion. |
| Enrique Perez | Refactorizacion, tests de listado/saludo y patron Secure Proxy. |
| Nikhil Baxani | Tests de confidencialidad, exportacion cifrada y Secure Strategy Factory. |
| Gael Espin | Tests de recuperacion, inyeccion y factory. |
| Sofia Casermeiro | Fuzz testing de contrasenas debiles y tests de proxy. |

## Ciclo S-TDD Aplicado

1. Se definieron requisitos funcionales y de seguridad.
2. Se escribieron pruebas unitarias con `unittest`.
3. Se implemento el codigo minimo para pasar las pruebas.
4. Se anadieron contratos con `icontract` para reforzar validaciones.
5. Se refactorizo separando responsabilidades en modulos de cifrado, almacenamiento, proxy, factory y logging.

## Pruebas Incluidas

La suite incluye 56 tests:

- Tests funcionales de anadir, recuperar, eliminar y listar.
- Tests de confidencialidad.
- Tests de integridad ante blobs manipulados.
- Tests de salt aleatorio por credencial y compatibilidad con blobs antiguos.
- Tests de robustez de contrasenas.
- Tests de autenticidad mediante proxy y timeout.
- Tests de auditoria y ausencia de datos sensibles en logs.
- Tests contra inyeccion en nombres de servicio.
- Tests de patrones Strategy, Secure Strategy Factory y Secure Proxy.

## Resultado de Tests

Comando:

```bash
python -m unittest discover -s tests -v
```

Resultado:

```text
Ran 56 tests in 1.144s
OK
```

## Conclusiones

S-TDD ayudo a convertir los requisitos de seguridad en comprobaciones automatizadas. La separacion por patrones de diseno mejoro la mantenibilidad y permitio probar cada responsabilidad de forma aislada.
