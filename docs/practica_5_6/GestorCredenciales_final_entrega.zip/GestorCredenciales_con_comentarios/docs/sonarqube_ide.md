# Guia de SonarQube for IDE

Referencias oficiales:

- Sonar: https://www.sonarsource.com/products/sonarqube/ide/
- JetBrains/PyCharm plugins: https://www.jetbrains.com/help/pycharm/managing-plugins.html

## Instalacion en PyCharm

1. Abrir PyCharm.
2. Ir a `Settings` > `Plugins`.
3. Buscar `SonarQube for IDE`.
4. Instalar el plugin y reiniciar PyCharm.
5. Abrir este proyecto desde la carpeta `GestorCredenciales`.

## Analisis Local

1. Esperar a que PyCharm indexe el proyecto.
2. Abrir la ventana de herramienta `SonarQube for IDE`.
3. Ejecutar el analisis local o revisar los problemas detectados en el editor.
4. Corregir los issues relevantes.
5. Guardar capturas de pantalla para la entrega.

## Capturas Recomendadas Para Entregar

- Vista general del proyecto analizado.
- Lista de issues detectados antes o despues de refactorizar.
- Evidencia de que los archivos principales se han analizado:
  - `gestor_credenciales.py`
  - `cifrador.py`
  - `proxy.py`
  - `factory.py`
  - `utils.py`
- Captura tras corregir issues importantes.

## Posibles Avisos Esperables

SonarQube puede marcar:

- Capturas genericas de `Exception`.
- Comentarios largos.
- Lineas largas en tests.

El uso anterior de salt fijo en `cifrador.py` fue sustituido por salt aleatorio por credencial. Si SonarQube mantiene algun aviso relacionado, revisar que afecte solo a `_FERNET_SALT_LEGACY`, que se conserva exclusivamente para descifrar datos antiguos.
