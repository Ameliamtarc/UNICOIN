"""
test_proxy.py
=============
Práctica 6 — Tests del patrón Secure Proxy for API.
Escritos por: Sofía Casermeiro

Verifica que:
  1. El proxy bloquea todas las operaciones con clave maestra incorrecta.
  2. El proxy permite todas las operaciones con clave correcta.
  3. Cada intento (exitoso o fallido) queda registrado en el log
     (principio de Registro de compromiso).
  4. La mediación es completa: todas las operaciones pasan por el proxy.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../"))

from src.gestor_credenciales.gestor_credenciales import GestorCredenciales
from src.gestor_credenciales.proxy import ProxyGestorCredenciales
from src.gestor_credenciales.log_seguro import LogSeguro


CLAVE       = "ClaveM@estra123!"
CLAVE_MAL   = "ClaveEquivoc@da9!"
PASSWORD_OK = "Abcd1234!@#$"


def _crear_proxy_con_log(log_file: str):
    """Helper: crea un proxy con log en fichero para inspección."""
    if os.path.exists(log_file):
        os.remove(log_file)
    log   = LogSeguro(log_file)
    g     = GestorCredenciales(clave_maestra=CLAVE, log=log)
    proxy = ProxyGestorCredenciales(g, CLAVE, log=log)
    return proxy, log_file


class TestProxyBloqueo(unittest.TestCase):
    """El proxy debe rechazar cualquier operación con clave incorrecta."""

    def setUp(self):
        g = GestorCredenciales(clave_maestra=CLAVE)
        self.proxy = ProxyGestorCredenciales(g, CLAVE)

    def test_proxy_bloquea_añadir_con_clave_incorrecta(self):
        """RS-4: añadir con clave incorrecta lanza PermissionError."""
        with self.assertRaises(PermissionError):
            self.proxy.añadir(CLAVE_MAL, "GitHub", "alice", PASSWORD_OK)

    def test_proxy_bloquea_recuperar_con_clave_incorrecta(self):
        """RS-4: recuperar con clave incorrecta lanza PermissionError."""
        with self.assertRaises(PermissionError):
            self.proxy.recuperar(CLAVE_MAL, "GitHub", "alice")

    def test_proxy_bloquea_eliminar_con_clave_incorrecta(self):
        """RS-4: eliminar con clave incorrecta lanza PermissionError."""
        with self.assertRaises(PermissionError):
            self.proxy.eliminar(CLAVE_MAL, "GitHub", "alice")

    def test_proxy_bloquea_listar_con_clave_incorrecta(self):
        """RS-4: listar con clave incorrecta lanza PermissionError."""
        with self.assertRaises(PermissionError):
            self.proxy.listar_servicios(CLAVE_MAL)


class TestProxyPermite(unittest.TestCase):
    """El proxy debe permitir todas las operaciones con clave correcta."""

    def setUp(self):
        g = GestorCredenciales(clave_maestra=CLAVE)
        self.proxy = ProxyGestorCredenciales(g, CLAVE)

    def test_proxy_permite_añadir_con_clave_correcta(self):
        """RS-4: añadir con clave correcta funciona."""
        self.proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)

    def test_proxy_permite_recuperar_con_clave_correcta(self):
        """RS-4: recuperar con clave correcta devuelve la contraseña."""
        self.proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        resultado = self.proxy.recuperar(CLAVE, "GitHub", "alice")
        self.assertEqual(resultado, PASSWORD_OK)

    def test_proxy_permite_eliminar_con_clave_correcta(self):
        """RS-4: eliminar con clave correcta retorna True."""
        self.proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        self.assertTrue(self.proxy.eliminar(CLAVE, "GitHub", "alice"))

    def test_proxy_permite_listar_con_clave_correcta(self):
        """RS-4: listar con clave correcta devuelve lista de servicios."""
        self.proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        servicios = self.proxy.listar_servicios(CLAVE)
        self.assertIn("GitHub", servicios)


class TestProxyRegistroCompromiso(unittest.TestCase):
    """
    Principio de Registro de compromiso:
    cada intento (exitoso o fallido) debe quedar en el log.
    """

    def test_intento_fallido_queda_en_log(self):
        """RS-5: un acceso denegado genera entrada en el log."""
        log_file = "/tmp/test_proxy_log_fallido.log"
        proxy, _ = _crear_proxy_con_log(log_file)
        try:
            proxy.añadir(CLAVE_MAL, "GitHub", "alice", PASSWORD_OK)
        except PermissionError:
            pass
        with open(log_file, "r", encoding="utf-8") as f:
            contenido = f.read()
        self.assertIn("incorrecta", contenido.lower())

    def test_acceso_exitoso_queda_en_log(self):
        """RS-5: un acceso autorizado genera entrada en el log."""
        log_file = "/tmp/test_proxy_log_exitoso.log"
        proxy, _ = _crear_proxy_con_log(log_file)
        proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        with open(log_file, "r", encoding="utf-8") as f:
            contenido = f.read()
        self.assertIn("autorizado", contenido.lower())

    def test_multiples_intentos_todos_registrados(self):
        """RS-5: múltiples intentos (buenos y malos) aparecen en el log."""
        log_file = "/tmp/test_proxy_log_multiples.log"
        proxy, _ = _crear_proxy_con_log(log_file)
        # 2 intentos fallidos
        for _ in range(2):
            try:
                proxy.recuperar(CLAVE_MAL, "S", "u")
            except PermissionError:
                pass
        # 1 intento exitoso
        proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        with open(log_file, "r", encoding="utf-8") as f:
            lineas = f.readlines()
        # Al menos: 1 init + 2 intentos fallidos + 1 autorizado + 1 añadir = 5
        self.assertGreaterEqual(len(lineas), 5)

    def test_log_no_contiene_password_en_intentos(self):
        """RS-6: el log de intentos del proxy no expone contraseñas."""
        log_file = "/tmp/test_proxy_log_nopassword.log"
        proxy, _ = _crear_proxy_con_log(log_file)
        proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        with open(log_file, "r", encoding="utf-8") as f:
            contenido = f.read()
        self.assertNotIn(PASSWORD_OK, contenido)


class TestProxyMediacionCompleta(unittest.TestCase):
    """
    Mediación completa: ninguna operación del gestor real
    puede saltarse el proxy.
    """

    def test_proxy_media_todas_las_operaciones(self):
        """Todas las operaciones del gestor están mediadas por el proxy."""
        g = GestorCredenciales(clave_maestra=CLAVE)
        proxy = ProxyGestorCredenciales(g, CLAVE)
        proxy.añadir(CLAVE, "S1", "u1", PASSWORD_OK)
        # Cada operación con clave mala debe ser rechazada
        operaciones_malas = [
            lambda: proxy.recuperar(CLAVE_MAL, "S1", "u1"),
            lambda: proxy.eliminar(CLAVE_MAL, "S1", "u1"),
            lambda: proxy.listar_servicios(CLAVE_MAL),
        ]
        for op in operaciones_malas:
            with self.subTest(op=op.__name__):
                with self.assertRaises(PermissionError):
                    op()


if __name__ == "__main__":
    unittest.main(verbosity=2)
