"""
test_factory.py
===============
Práctica 6 — Tests del patrón Secure Strategy Factory.
Escritos por: Nikhil Baxani

Verifica que:
  1. La fábrica devuelve CifradorFernet cuando el tipo/rol es válido.
  2. La fábrica falla por defecto con tipo desconocido (a prueba de fallos).
  3. La fábrica falla si las credenciales son insuficientes (mínimo privilegio).
  4. Los cifradores obtenidos de la fábrica funcionan correctamente.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../"))

from src.gestor_credenciales.factory import CifradorFactory
from src.gestor_credenciales.cifrador import CifradorBase, CifradorFernet


CLAVE       = "ClaveM@estra123!"
PASSWORD_OK = "Abcd1234!@#$"


class TestCifradorFactoryTipoExplicito(unittest.TestCase):
    """Tests para obtener_cifrador() con nombre de tipo explícito."""

    def test_obtener_cifrador_fernet_devuelve_instancia_CifradorFernet(self):
        """La fábrica devuelve CifradorFernet para el tipo 'fernet'."""
        cifrador = CifradorFactory.obtener_cifrador("fernet")
        self.assertIsInstance(cifrador, CifradorFernet)

    def test_cifrador_obtenido_es_subclase_de_CifradorBase(self):
        """DIP: el objeto devuelto implementa CifradorBase."""
        cifrador = CifradorFactory.obtener_cifrador("fernet")
        self.assertIsInstance(cifrador, CifradorBase)

    def test_cifrador_obtenido_cifra_y_descifra_correctamente(self):
        """El cifrador devuelto por la fábrica funciona extremo a extremo."""
        cifrador = CifradorFactory.obtener_cifrador("fernet")
        blob = cifrador.cifrar(PASSWORD_OK, CLAVE)
        self.assertEqual(cifrador.descifrar(blob, CLAVE), PASSWORD_OK)

    def test_tipo_desconocido_lanza_ValueError(self):
        """A prueba de fallos por defecto: tipo desconocido lanza ValueError."""
        with self.assertRaises(ValueError):
            CifradorFactory.obtener_cifrador("rsa-obsoleto")

    def test_tipo_vacio_lanza_ValueError(self):
        """A prueba de fallos: tipo vacío lanza ValueError."""
        with self.assertRaises(ValueError):
            CifradorFactory.obtener_cifrador("")

    def test_cada_llamada_devuelve_instancia_nueva(self):
        """La fábrica crea una instancia nueva en cada llamada."""
        c1 = CifradorFactory.obtener_cifrador("fernet")
        c2 = CifradorFactory.obtener_cifrador("fernet")
        self.assertIsNot(c1, c2)


class TestCifradorFactoryPorRol(unittest.TestCase):
    """Tests para obtener_cifrador_para_rol() con credenciales."""

    def test_rol_admin_con_clave_valida_devuelve_cifrador(self):
        """Mínimo privilegio: rol 'admin' con clave válida obtiene cifrador."""
        cifrador = CifradorFactory.obtener_cifrador_para_rol("admin", CLAVE)
        self.assertIsInstance(cifrador, CifradorBase)

    def test_rol_usuario_con_clave_valida_devuelve_cifrador(self):
        """Mínimo privilegio: rol 'usuario' con clave válida obtiene cifrador."""
        cifrador = CifradorFactory.obtener_cifrador_para_rol("usuario", CLAVE)
        self.assertIsInstance(cifrador, CifradorBase)

    def test_rol_desconocido_lanza_PermissionError(self):
        """A prueba de fallos: rol no autorizado lanza PermissionError."""
        with self.assertRaises(PermissionError):
            CifradorFactory.obtener_cifrador_para_rol("intruso", CLAVE)

    def test_clave_vacia_lanza_PermissionError(self):
        """A prueba de fallos: clave vacía lanza PermissionError."""
        with self.assertRaises(PermissionError):
            CifradorFactory.obtener_cifrador_para_rol("admin", "")

    def test_clave_none_lanza_PermissionError(self):
        """A prueba de fallos: clave None lanza PermissionError."""
        with self.assertRaises(PermissionError):
            CifradorFactory.obtener_cifrador_para_rol("admin", None)

    def test_cifrador_de_rol_cifra_y_descifra(self):
        """El cifrador obtenido por rol funciona correctamente."""
        cifrador = CifradorFactory.obtener_cifrador_para_rol("admin", CLAVE)
        blob = cifrador.cifrar(PASSWORD_OK, CLAVE)
        self.assertEqual(cifrador.descifrar(blob, CLAVE), PASSWORD_OK)


if __name__ == "__main__":
    unittest.main(verbosity=2)
