"""
test_cifrador.py
================
Práctica 6 — Tests del patrón Strategy para cifrado.
Escritos por: Lara Moriel

Verifica que:
  1. CifradorFernet cifra y descifra correctamente.
  2. El gestor puede intercambiar el cifrador sin modificar su código (OCP).
  3. Descifrar con clave incorrecta lanza ValueError (integridad).
  4. El blob cifrado no contiene la contraseña en claro (RS-1).
"""

import os
import sys
import unittest

from cryptography.fernet import Fernet

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../"))

from src.gestor_credenciales.cifrador import (
    _FERNET_SALT_LEGACY,
    _derivar_clave_fernet,
    CifradorBase,
    CifradorFernet,
)
from src.gestor_credenciales.gestor_credenciales import (
    GestorCredenciales, AlmacenamientoMemoria,
)


CLAVE       = "ClaveM@estra123!"
CLAVE_MAL   = "OtraClaveWrong9!"
PASSWORD_OK = "Abcd1234!@#$"


class TestCifradorFernet(unittest.TestCase):
    """Tests para CifradorFernet (Strategy concreto)."""

    def setUp(self):
        self.cifrador = CifradorFernet()

    def test_cifrar_y_descifrar_correcto(self):
        """CifradorFernet cifra y descifra recuperando el texto original."""
        blob = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        resultado = self.cifrador.descifrar(blob, CLAVE)
        self.assertEqual(resultado, PASSWORD_OK)

    def test_blob_no_contiene_texto_original(self):
        """RS-1: el blob cifrado no debe contener la contraseña en claro."""
        blob = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        self.assertNotEqual(blob, PASSWORD_OK)
        self.assertNotIn(PASSWORD_OK, blob)

    def test_blob_nuevo_incluye_version_y_salt(self):
        """Los blobs nuevos guardan version, salt aleatorio y token Fernet."""
        blob = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        partes = blob.split(":", 2)
        self.assertEqual(len(partes), 3)
        self.assertEqual(partes[0], "v2")
        self.assertTrue(partes[1])
        self.assertTrue(partes[2])

    def test_salt_aleatorio_por_blob(self):
        """La misma entrada usa salts distintos en cifrados distintos."""
        blob1 = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        blob2 = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        salt1 = blob1.split(":", 2)[1]
        salt2 = blob2.split(":", 2)[1]
        self.assertNotEqual(salt1, salt2)

    def test_descifrar_con_clave_incorrecta_lanza_ValueError(self):
        """RS-2: descifrar con clave errónea lanza ValueError."""
        blob = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        with self.assertRaises(ValueError):
            self.cifrador.descifrar(blob, CLAVE_MAL)

    def test_blob_manipulado_lanza_ValueError(self):
        """RS-2: blob alterado lanza ValueError (integridad Fernet HMAC)."""
        blob = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        blob_corrupto = blob[:-4] + "XXXX"
        with self.assertRaises(ValueError):
            self.cifrador.descifrar(blob_corrupto, CLAVE)

    def test_descifra_blob_legacy_con_salt_fijo(self):
        """Compatibilidad: descifra blobs antiguos sin prefijo v2."""
        f = Fernet(_derivar_clave_fernet(CLAVE, _FERNET_SALT_LEGACY))
        blob_legacy = f.encrypt(PASSWORD_OK.encode("utf-8")).decode("utf-8")
        resultado = self.cifrador.descifrar(blob_legacy, CLAVE)
        self.assertEqual(resultado, PASSWORD_OK)

    def test_misma_entrada_produce_blobs_distintos(self):
        """Fernet incluye IV aleatorio: misma entrada → blobs distintos."""
        blob1 = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        blob2 = self.cifrador.cifrar(PASSWORD_OK, CLAVE)
        self.assertNotEqual(blob1, blob2)

    def test_cifrador_es_subclase_de_CifradorBase(self):
        """DIP: CifradorFernet implementa la abstracción CifradorBase."""
        self.assertIsInstance(self.cifrador, CifradorBase)


class TestOCPIntercambioCifrador(unittest.TestCase):
    """
    Verifica OCP: el GestorCredenciales acepta cualquier CifradorBase
    sin modificar su propio código.
    """

    def test_gestor_funciona_con_cifrador_fernet_inyectado(self):
        """OCP: inyectar CifradorFernet explícitamente no rompe el gestor."""
        cifrador = CifradorFernet()
        g = GestorCredenciales(
            clave_maestra=CLAVE,
            cifrado=cifrador,
        )
        g.añadir("GitHub", "alice", PASSWORD_OK)
        self.assertEqual(g.recuperar("GitHub", "alice"), PASSWORD_OK)

    def test_gestor_funciona_con_cifrador_alternativo(self):
        """
        OCP: un cifrador alternativo (stub) puede sustituir a CifradorFernet
        sin tocar GestorCredenciales.
        """
        class CifradorStub(CifradorBase):
            """Cifrador de prueba que invierte el texto (no seguro, solo para test OCP)."""
            def cifrar(self, texto: str, clave: str) -> str:
                return texto[::-1]
            def descifrar(self, blob: str, clave: str) -> str:
                return blob[::-1]

        g = GestorCredenciales(
            clave_maestra=CLAVE,
            cifrado=CifradorStub(),
        )
        g.añadir("TestSvc", "user", PASSWORD_OK)
        self.assertEqual(g.recuperar("TestSvc", "user"), PASSWORD_OK)


if __name__ == "__main__":
    unittest.main(verbosity=2)
