"""
test_gestor_credenciales.py
===========================
Práctica 5 — Tests funcionales y de seguridad del GestorCredenciales.
Ciclo S-TDD: tests escritos por Lara Moriel / Gael Espín / Nikhil Baxani / Sofía Casermeiro.
Implementación realizada por Amelia Martínez.
Refactorización realizada por Enrique Pérez.

Cubre los 7 requisitos de seguridad + todos los requisitos funcionales.
Usa unittest (comportamiento) + icontract (Design-By-Contract).

Distribución por persona según especificación:
  Lara Moriel      : test_añadir_credencial, test_eliminar_credencial
  Amelia Martínez  : test_acceso_con_clave_maestra_erronea,
                     test_timeout_sesion_clave_maestra
  Enrique Pérez    : test_listar_servicios, test_saludar
  Nikhil Baxani    : test_password_no_almacenado_en_plano,
                     test_exportar_credenciales_cifradas
  Gael Espín       : test_deteccion_inyeccion_servicio,
                     test_recuperar_credencial
  Sofía Casermeiro : test_fuzz_politica_passwords_debiles
"""

import os
import sys
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../"))

from src.gestor_credenciales.gestor_credenciales import (
    GestorCredenciales,
    AlmacenamientoMemoria,
)
from src.gestor_credenciales.proxy import ProxyGestorCredenciales
from src.gestor_credenciales.factory import CifradorFactory
from src.gestor_credenciales.cifrador import CifradorFernet
from src.gestor_credenciales.utils import (
    cifrar, descifrar, validar_password, validar_nombre_servicio,
)
from src.gestor_credenciales.log_seguro import LogSeguro


CLAVE        = "ClaveM@estra123!"
PASSWORD_OK  = "Abcd1234!@#$"
PASSWORD_OK2 = "Xyz9!@#$abcD"


def gestor(timeout: int = 300) -> GestorCredenciales:
    """Crea un GestorCredenciales fresco para cada test."""
    return GestorCredenciales(clave_maestra=CLAVE, timeout_segundos=timeout)


# ══════════════════════════════════════════════════════════════════
# TESTS FUNCIONALES  — escritos por Lara / Gael / Enrique / Nikhil
# ══════════════════════════════════════════════════════════════════

class TestFuncional(unittest.TestCase):

    # ── Lara Moriel ───────────────────────────────────────────────

    def test_añadir_credencial(self):
        """RF-1: añadir una credencial y verificar que se puede recuperar."""
        g = gestor()
        g.añadir("GitHub", "alice", PASSWORD_OK)
        self.assertEqual(g.recuperar("GitHub", "alice"), PASSWORD_OK)

    def test_eliminar_credencial(self):
        """RF-3: eliminar una credencial existente; recuperarla lanza KeyError."""
        g = gestor()
        g.añadir("GitHub", "alice", PASSWORD_OK)
        self.assertTrue(g.eliminar("GitHub", "alice"))
        with self.assertRaises(KeyError):
            g.recuperar("GitHub", "alice")

    # ── Enrique Pérez ─────────────────────────────────────────────

    def test_listar_servicios(self):
        """RF-4: listar todos los servicios almacenados."""
        g = gestor()
        g.añadir("GitHub", "alice", PASSWORD_OK)
        g.añadir("VulnDB", "bob", PASSWORD_OK2)
        servicios = g.listar_servicios()
        self.assertIn("GitHub", servicios)
        self.assertIn("VulnDB", servicios)

    def test_saludar(self):
        """RF-extra: saludar() retorna mensaje de bienvenida no sensitivo."""
        g = gestor()
        msg = g.saludar()
        self.assertIsInstance(msg, str)
        self.assertGreater(len(msg), 0)
        # No debe contener la clave maestra ni contraseñas
        self.assertNotIn(CLAVE, msg)
        self.assertNotIn(PASSWORD_OK, msg)

    # ── Gael Espín ────────────────────────────────────────────────

    def test_recuperar_credencial(self):
        """RF-2: recuperar credencial existente e inexistente."""
        g = gestor()
        g.añadir("GitHub", "alice", PASSWORD_OK)
        self.assertEqual(g.recuperar("GitHub", "alice"), PASSWORD_OK)
        with self.assertRaises(KeyError):
            g.recuperar("NoExiste", "nadie")

    # ── Nikhil Baxani ─────────────────────────────────────────────

    def test_exportar_credenciales_cifradas(self):
        """RF-extra: exportar retorna blobs cifrados, nunca contraseñas en claro."""
        g = gestor()
        g.añadir("GitHub", "alice", PASSWORD_OK)
        g.añadir("VulnDB", "bob", PASSWORD_OK2)
        exportado = g.exportar_credenciales_cifradas()
        self.assertIn("GitHub", exportado)
        self.assertIn("VulnDB", exportado)
        # Los valores son blobs, nunca contraseñas en claro
        blob_alice = exportado["GitHub"]["alice"]
        self.assertNotEqual(blob_alice, PASSWORD_OK)
        self.assertNotIn(PASSWORD_OK, blob_alice)

    # ── Tests funcionales adicionales ────────────────────────────

    def test_eliminar_inexistente(self):
        """RF-3: eliminar credencial inexistente retorna False."""
        g = gestor()
        self.assertFalse(g.eliminar("NoExiste", "nadie"))

    def test_multiples_usuarios_mismo_servicio(self):
        """RF-1/2: varios usuarios en el mismo servicio."""
        g = gestor()
        g.añadir("GitHub", "alice", PASSWORD_OK)
        g.añadir("GitHub", "bob", PASSWORD_OK2)
        self.assertEqual(g.recuperar("GitHub", "alice"), PASSWORD_OK)
        self.assertEqual(g.recuperar("GitHub", "bob"), PASSWORD_OK2)


# ══════════════════════════════════════════════════════════════════
# TESTS DE SEGURIDAD  — escritos por Amelia / Nikhil / Gael / Sofía
# ══════════════════════════════════════════════════════════════════

class TestSeguridad(unittest.TestCase):

    # ── Amelia Martínez ───────────────────────────────────────────

    def test_acceso_con_clave_maestra_erronea(self):
        """RS-4: el proxy rechaza cualquier operación con clave incorrecta."""
        g = gestor()
        proxy = ProxyGestorCredenciales(g, CLAVE)
        with self.assertRaises(PermissionError):
            proxy.añadir("ClaveWrong1!", "GitHub", "alice", PASSWORD_OK)
        with self.assertRaises(PermissionError):
            proxy.recuperar("ClaveWrong1!", "GitHub", "alice")
        with self.assertRaises(PermissionError):
            proxy.eliminar("ClaveWrong1!", "GitHub", "alice")
        with self.assertRaises(PermissionError):
            proxy.listar_servicios("ClaveWrong1!")

    def test_timeout_sesion_clave_maestra(self):
        """RS-4: operación tras timeout de sesión lanza PermissionError."""
        # Creamos gestor con timeout de 0 segundos (expira inmediatamente)
        g = GestorCredenciales(clave_maestra=CLAVE, timeout_segundos=0)
        time.sleep(0.01)   # pequeña espera para asegurar expiración
        with self.assertRaises(PermissionError):
            g.listar_servicios()

    # ── Nikhil Baxani ─────────────────────────────────────────────

    def test_password_no_almacenado_en_plano(self):
        """RS-1: la contraseña no debe almacenarse sin cifrar en el backend."""
        store = AlmacenamientoMemoria()
        g = GestorCredenciales(clave_maestra=CLAVE, almacenamiento=store)
        g.añadir("GitHub", "alice", PASSWORD_OK)
        blob = store.recuperar("GitHub", "alice")
        self.assertIsNotNone(blob)
        self.assertNotEqual(blob, PASSWORD_OK)
        self.assertNotIn(PASSWORD_OK, blob)

    def test_exportar_credenciales_cifradas_no_expone_passwords(self):
        """RS-1: la exportación nunca contiene contraseñas en claro."""
        g = gestor()
        passwords = [PASSWORD_OK, PASSWORD_OK2, "Secure#Pass77!X"]
        servicios  = ["GitHub", "VulnDB", "AWS"]
        for svc, pwd in zip(servicios, passwords):
            g.añadir(svc, "user", pwd)
        exportado = g.exportar_credenciales_cifradas()
        exportado_str = str(exportado)
        for pwd in passwords:
            self.assertNotIn(pwd, exportado_str)

    # ── Gael Espín ────────────────────────────────────────────────

    def test_deteccion_inyeccion_servicio(self):
        """RS-7: nombres de servicio con caracteres maliciosos son rechazados."""
        g = gestor()
        payloads_inyeccion = [
            "GitHub; DROP TABLE users;",
            "'OR'1'='1",
            "<script>alert(1)</script>",
            "../../etc/passwd",
            "servicio\nnueva_linea",
            "",
        ]
        for payload in payloads_inyeccion:
            with self.subTest(payload=payload):
                with self.assertRaises(Exception):
                    g.añadir(payload, "alice", PASSWORD_OK)

    def test_recuperar_credencial_integridad(self):
        """RS-2: blob manipulado lanza ValueError (integridad AES/Fernet)."""
        store = AlmacenamientoMemoria()
        g = GestorCredenciales(clave_maestra=CLAVE, almacenamiento=store)
        g.añadir("GitHub", "alice", PASSWORD_OK)
        blob_original = store.recuperar("GitHub", "alice")
        # Manipulamos el blob directamente en el backend
        store.guardar("GitHub", "alice", blob_original[:-4] + "XXXX")
        with self.assertRaises(ValueError):
            g.recuperar("GitHub", "alice")

    # ── Sofía Casermeiro ──────────────────────────────────────────

    def test_fuzz_politica_passwords_debiles(self):
        """
        RS-3: fuzz test — el gestor rechaza una amplia variedad de contraseñas
        que no cumplen la política de seguridad (longitud, complejidad, etc.).
        Cada caso es un subTest independiente para facilitar el diagnóstico.
        """
        g = gestor()

        passwords_debiles = [
            # Demasiado cortas
            "Abc1!",
            "A1!aBcDe",
            "Short1!@",
            # Sin mayúsculas
            "abcd1234!@#$",
            "minuscula123!",
            "todo_minuscula1!",
            # Sin minúsculas
            "ABCD1234!@#$",
            "MAYUSCULAS123!",
            "SOLOARRIBA99!",
            # Sin dígitos
            "Abcdefghijk!",
            "SinNumero!@#$",
            "Letras_Solo!@",
            # Sin símbolos
            "Abcde12345678",
            "SinSimbolo1234",
            "NoSymbol12345A",
            # Completamente simple
            "password",
            "12345678",
            "qwerty",
            "abc",
            "",
        ]

        for pwd in passwords_debiles:
            with self.subTest(password=pwd):
                with self.assertRaises(Exception,
                                       msg=f"Se esperaba rechazo para: '{pwd}'"):
                    g.añadir("TestServicio", "tester", pwd)

    # ── Tests de seguridad adicionales ───────────────────────────

    def test_clave_maestra_incorrecta_no_descifra(self):
        """RS-2: descifrar con clave maestra incorrecta falla."""
        blob = cifrar(PASSWORD_OK, CLAVE)
        with self.assertRaises(Exception):
            descifrar(blob, "ClaveEquivocada999!")

    def test_log_no_contiene_password(self):
        """RS-6: el log no debe contener la contraseña en claro."""
        log_file = "/tmp/test_gestor_log_sensitivo.log"
        if os.path.exists(log_file):
            os.remove(log_file)
        log = LogSeguro(log_file)
        g = GestorCredenciales(clave_maestra=CLAVE, log=log)
        g.añadir("GitHub", "alice", PASSWORD_OK)
        g.recuperar("GitHub", "alice")
        with open(log_file, "r", encoding="utf-8") as f:
            contenido = f.read()
        self.assertNotIn(PASSWORD_OK, contenido)

    def test_proxy_permite_operaciones_con_clave_correcta(self):
        """RS-4: el proxy permite operar con clave maestra correcta."""
        g = gestor()
        proxy = ProxyGestorCredenciales(g, CLAVE)
        proxy.añadir(CLAVE, "GitHub", "alice", PASSWORD_OK)
        self.assertEqual(proxy.recuperar(CLAVE, "GitHub", "alice"), PASSWORD_OK)
        servicios = proxy.listar_servicios(CLAVE)
        self.assertIn("GitHub", servicios)
        self.assertTrue(proxy.eliminar(CLAVE, "GitHub", "alice"))

    def test_nombre_servicio_vacio_rechazado(self):
        """RS-7: nombre de servicio vacío rechazado."""
        g = gestor()
        with self.assertRaises(Exception):
            g.añadir("", "alice", PASSWORD_OK)

    def test_clave_maestra_corta_rechazada(self):
        """RS-4: clave maestra de menos de 8 caracteres rechazada."""
        with self.assertRaises(ValueError):
            GestorCredenciales(clave_maestra="corta")


if __name__ == "__main__":
    unittest.main(verbosity=2)
